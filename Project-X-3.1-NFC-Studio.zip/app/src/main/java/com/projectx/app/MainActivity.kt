package com.projectx.app

import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.hardware.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.nfc.NfcAdapter
import android.net.wifi.WifiManager
import android.os.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Base64
import java.util.Locale

private val BG = Color(0xFF090A0F)
private val PANEL = Color(0xFF171923)
private val RED = Color(0xFFE53945)
private val MUTED = Color(0xFF9BA0AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProjectXApp(this) }
    }
}

@Composable
private fun ProjectXApp(ctx: Context) {
    val pages = listOf("Главная", "Инструменты", "IR-пульт", "NFC Studio", "QR Studio", "Конвертер", "Диагностика")
    var page by remember { mutableStateOf(pages[0]) }
    var last by remember { mutableStateOf("Ожидание команды") }
    var torch by remember { mutableStateOf(false) }
    var qrInput by remember { mutableStateOf("https://example.com") }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var textInput by remember { mutableStateOf("Project X") }
    var textOutput by remember { mutableStateOf("") }
    var decode by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = RED, background = BG, surface = PANEL)) {
        Scaffold(
            containerColor = BG,
            topBar = {
                Column(Modifier.fillMaxWidth().background(PANEL).padding(18.dp)) {
                    Text("PROJECT X  /  DEVICE LAB", color = RED, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(page, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = PANEL) {
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Build, Icons.Default.SettingsRemote, Icons.Default.Nfc, Icons.Default.QrCode, Icons.Default.SwapHoriz, Icons.Default.Memory)
                    pages.forEachIndexed { i, label ->
                        NavigationBarItem(selected = page == label, onClick = { page = label },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 8.sp, maxLines = 1) })
                    }
                }
            }
        ) { insets ->
            LazyColumn(Modifier.fillMaxSize().padding(insets).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (page) {
                    "Главная" -> {
                        item { Text("Локальная панель управления", color = MUTED) }
                        item { Info("Устройство", "${Build.MANUFACTURER} ${Build.MODEL}", "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}") }
                        item { Info("Статус", "Система готова", "Набор возможностей зависит от аппаратной части") }
                        item { Info("Последнее действие", last, "Действия выполняются локально") }
                        item { Action("Фонарик", "Переключить LED-вспышку", torch) {
                            torch = toggleTorch(ctx, !torch); last = if (torch) "Фонарик включён" else "Фонарик выключен/недоступен"
                        } }
                        item { Action("Вибротест", "Короткая проверка вибромотора", false) { vibrate(ctx); last = "Вибротест выполнен" } }
                    }
                    "Инструменты" -> {
                        item { Action("Фонарик", "Если есть LED-вспышка", torch) {
                            torch = toggleTorch(ctx, !torch); last = if (torch) "Фонарик включён" else "Фонарик выключен/недоступен"
                        } }
                        item { Action("Вибрация", "Короткий тест", false) { vibrate(ctx); last = "Вибротест выполнен" } }
                        item { Info("NFC", nfcStatus(ctx), "Только проверка статуса адаптера") }
                        item { Info("Wi-Fi", wifiStatus(ctx), "Без чтения паролей или сетевого трафика") }
                        item { Info("IR", irStatus(ctx), "Требуется встроенный IR blaster") }
                        item { Info("Датчики", sensors(ctx), "Датчики, доступные системе") }
                        item { Info("Экран", "${ctx.resources.displayMetrics.widthPixels} × ${ctx.resources.displayMetrics.heightPixels}", "Разрешение в физических пикселях") }
                    }
                    "IR-пульт" -> {
                        item { Info("Совместимость", irStatus(ctx), "IR есть не во всех смартфонах") }
                        item { Action("Тестовый IR-импульс", "Только тест передатчика; без обучения и копирования", false) {
                            sendTestIr(ctx); last = "Тестовый IR-импульс"
                        } }
                        item { Text("Не поддерживаются управление воротами, дверями, замками и системами доступа. Используй IR только для собственной бытовой техники.", color = MUTED, fontSize = 12.sp) }
                    }

                    "NFC Studio" -> {
                        item { NfcStudio(activity = ctx as ComponentActivity) }
                    }
                    "QR Studio" -> {
                        item { OutlinedTextField(qrInput, { qrInput = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Текст или ссылка") }) }
                        item { Button(onClick = { qr = makeQr(qrInput) }, modifier = Modifier.fillMaxWidth()) { Text("Создать QR-код") } }
                        item { qr?.let { Image(it.asImageBitmap(), "QR", Modifier.size(230.dp).background(Color.White).padding(8.dp)) } }
                    }
                    "Конвертер" -> {
                        item { OutlinedTextField(textInput, { textInput = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Входные данные") }) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = !decode, onClick = { decode = false }, label = { Text("В Base64") })
                                FilterChip(selected = decode, onClick = { decode = true }, label = { Text("Из Base64") })
                            }
                        }
                        item { Button(onClick = {
                            textOutput = try {
                                if (!decode) Base64.getEncoder().encodeToString(textInput.toByteArray(Charsets.UTF_8))
                                else String(Base64.getDecoder().decode(textInput), Charsets.UTF_8)
                            } catch (_: Exception) { "Ошибка: проверь входные данные" }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Преобразовать") } }
                        item {
                            if (textOutput.isNotEmpty()) {
                                Info("Результат", textOutput, "Результат можно скопировать")
                                Button(onClick = { copy(ctx, textOutput); Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show() }) {
                                    Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("Копировать")
                                }
                            }
                        }
                    }
                    "Диагностика" -> {
                        item { Info("Модель", "${Build.MANUFACTURER} ${Build.MODEL}", "Device: ${Build.DEVICE}") }
                        item { Info("Android", Build.VERSION.RELEASE, "SDK ${Build.VERSION.SDK_INT}") }
                        item { Info("Батарея", battery(ctx), "Системный BatteryManager") }
                        item { Info("Датчики", sensors(ctx), "Количество и примеры названий") }
                        item { Info("Вспышка", if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) "Есть" else "Не обнаружена", "Аппаратная возможность") }
                        item { Info("NFC", nfcStatus(ctx), "Состояние NFC") }
                        item { Info("Wi-Fi", wifiStatus(ctx), "Состояние Wi-Fi") }
                        item { Info("IR", irStatus(ctx), "Встроенный инфракрасный передатчик") }
                    }
                }
            }
        }
    }
}

@Composable
private fun Info(title: String, value: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title.uppercase(Locale.getDefault()), color = RED, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = MUTED, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Action(title: String, detail: String, active: Boolean, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(detail, color = MUTED, fontSize = 12.sp)
            }
            Button(onClick = onClick) { Text(if (active) "Выключить" else "Запуск") }
        }
    }
}

private fun toggleTorch(ctx: Context, on: Boolean): Boolean {
    return try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return false
        cm.setTorchMode(id, on)
        on
    } catch (_: Exception) { false }
}

private fun vibrate(ctx: Context) {
    try {
        val v = if (Build.VERSION.SDK_INT >= 31) (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") (ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        v.vibrate(VibrationEffect.createOneShot(160, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (_: Exception) { }
}

private fun irStatus(ctx: Context): String {
    val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    return if (ir?.hasIrEmitter() == true) "IR-передатчик обнаружен" else "IR-передатчик не обнаружен"
}

private fun sendTestIr(ctx: Context) {
    val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    if (ir?.hasIrEmitter() != true) {
        Toast.makeText(ctx, "Нет встроенного IR-передатчика", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        ir.transmit(38000, intArrayOf(9000, 4500, 560, 560, 560, 560, 560, 1690, 560, 560))
        Toast.makeText(ctx, "Тестовый импульс отправлен", Toast.LENGTH_SHORT).show()
    } catch (_: Exception) { Toast.makeText(ctx, "IR-команда не отправлена", Toast.LENGTH_SHORT).show() }
}

private fun makeQr(value: String): Bitmap? {
    if (value.isBlank()) return null
    return try {
        val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 600, 600)
        Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565).also { bmp ->
            for (x in 0 until 600) for (y in 0 until 600) bmp.setPixel(x, y, if (matrix[x, y]) AColor.BLACK else AColor.WHITE)
        }
    } catch (_: Exception) { null }
}

private fun copy(ctx: Context, value: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Project X", value))
}

private fun battery(ctx: Context): String {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val n = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    return if (n in 0..100) "$n%" else "Нет данных"
}

private fun sensors(ctx: Context): String {
    val list = (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getSensorList(Sensor.TYPE_ALL)
    return if (list.isEmpty()) "Не обнаружены" else "${list.size} шт. • " + list.take(4).joinToString { it.name }
}

private fun nfcStatus(ctx: Context): String {
    val nfc = NfcAdapter.getDefaultAdapter(ctx) ?: return "Не поддерживается"
    return if (nfc.isEnabled) "Поддерживается и включён" else "Поддерживается, но выключен"
}

private fun wifiStatus(ctx: Context): String {
    val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    return if (wifi.isWifiEnabled) "Wi-Fi включён" else "Wi-Fi выключен"
}
